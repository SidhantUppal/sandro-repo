﻿using System;

namespace PushSharp.Apple
{
    public class ApnsHttp2Connection
    {
        public ApnsHttp2Connection ()
        {
        }
    }
}

