﻿using System;

namespace PushSharp.Core
{
	public class NotificationBlockingCollection
	{
		public NotificationBlockingCollection ()
		{
		}
	}
}

